require("dotenv").config();
const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");
const mongoose = require("mongoose");
const Player = require("./models/Player");

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*", // Update to frontend URL after deployment
    credentials: true
  }
});

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// Test route
app.get("/api/test", (req, res) => res.send("Backend running"));

// Socket.IO auction & match simulation
let rooms = {};

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("joinRoom", ({ roomId, username }) => {
    socket.join(roomId);
    if (!rooms[roomId]) rooms[roomId] = { players: {}, auction: [], squads: {} };
    rooms[roomId].players[socket.id] = username;
    io.to(roomId).emit("roomUpdate", rooms[roomId]);
  });

  socket.on("startAuction", ({ roomId, players }) => {
    rooms[roomId].auction = players;
    io.to(roomId).emit("auctionStart", players);
  });

  socket.on("buyPlayer", ({ roomId, player, buyer }) => {
    rooms[roomId].squads[buyer] = rooms[roomId].squads[buyer] || [];
    rooms[roomId].squads[buyer].push(player);
    io.to(roomId).emit("updateSquad", rooms[roomId].squads);
  });

  socket.on("startMatch", ({ roomId }) => {
    const users = Object.keys(rooms[roomId].squads);
    if (users.length < 2) return;
    const teamA = rooms[roomId].squads[users[0]];
    const teamB = rooms[roomId].squads[users[1]];

    // Simple match simulation
    const simulateMatch = (a, b) => {
      const goalsA = Math.floor(Math.random() * 5);
      const goalsB = Math.floor(Math.random() * 5);
      return {
        score: `${goalsA} - ${goalsB}`,
        winner: goalsA > goalsB ? users[0] : goalsB > goalsA ? users[1] : "Draw"
      };
    };

    io.to(roomId).emit("matchResult", simulateMatch(teamA, teamB));
  });

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
    for (const roomId in rooms) {
      delete rooms[roomId].players[socket.id];
      io.to(roomId).emit("roomUpdate", rooms[roomId]);
    }
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));