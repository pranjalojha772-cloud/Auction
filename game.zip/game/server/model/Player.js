const mongoose = require("mongoose");

const playerSchema = new mongoose.Schema({
  name: String,
  rating: Number,
  position: String,
  basePrice: Number
});

module.exports = mongoose.model("Player", playerSchema);