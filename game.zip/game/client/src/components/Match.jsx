import React, { useState, useEffect } from "react";

export default function Match({ socket, roomId }) {
  const [matchResult, setMatchResult] = useState(null);

  useEffect(() => {
    socket.on("matchResult", (data) => {
      setMatchResult(data);
    });
  }, []);

  const startMatch = () => {
    socket.emit("startMatch", { roomId });
  };

  if (!matchResult)
    return (
      <div className="p-4 bg-gray-800 text-white rounded-lg">
        <h2 className="text-xl font-bold mb-2">Match Simulation</h2>
        <button
          onClick={startMatch}
          className="bg-green-500 px-4 py-2 rounded hover:bg-green-700"
        >
          Start Match
        </button>
      </div>
    );

  return (
    <div className="p-4 bg-gray-800 text-white rounded-lg mt-4">
      <h2 className="text-xl font-bold mb-2">Match Result</h2>
      <p>Score: {matchResult.score}</p>
      <p>Winner: {matchResult.winner}</p>
    </div>
  );
}