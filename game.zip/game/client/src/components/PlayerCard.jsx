export default function PlayerCard({ player }) {
  return (
    <div className="bg-gray-800 text-white p-3 rounded-lg shadow-md">
      <h2 className="text-lg font-bold">{player.name}</h2>
      <p>Rating: {player.rating}</p>
      <p>Position: {player.position}</p>
    </div>
  );
}