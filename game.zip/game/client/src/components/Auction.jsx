import React, { useState, useEffect } from "react";
import PlayerCard from "./PlayerCard.jsx";

export default function Auction({ socket, roomId, username, players }) {
  const [currentPlayer, setCurrentPlayer] = useState(null);
  const [bids, setBids] = useState({});
  const [auctionIndex, setAuctionIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);

  useEffect(() => {
    if (players.length > 0) setCurrentPlayer(players[0]);
  }, [players]);

  useEffect(() => {
    if (!currentPlayer) return;

    const timer = setInterval(() => {
      setTimeLeft((t) => t - 1);
    }, 1000);

    if (timeLeft <= 0) {
      // Auction ends, assign player to highest bidder
      const highestBidder = Object.keys(bids).reduce(
        (a, b) => (bids[a] > bids[b] ? a : b),
        Object.keys(bids)[0]
      );
      if (highestBidder) {
        socket.emit("buyPlayer", {
          roomId,
          player: currentPlayer,
          buyer: highestBidder,
        });
      }

      setAuctionIndex((i) => i + 1);
      setCurrentPlayer(players[auctionIndex + 1] || null);
      setBids({});
      setTimeLeft(10);
    }

    return () => clearInterval(timer);
  }, [timeLeft, currentPlayer, bids]);

  const placeBid = (amount) => {
    setBids({ ...bids, [username]: amount });
  };

  if (!currentPlayer) return <div>No players left in auction</div>;

  return (
    <div className="p-4 bg-gray-900 text-white rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-2">Current Auction</h2>
      <PlayerCard player={currentPlayer} />
      <p className="my-2">Time left: {timeLeft}s</p>

      <div className="flex gap-2 my-2">
        {[10, 20, 30, 40, 50].map((amt) => (
          <button
            key={amt}
            onClick={() => placeBid(amt)}
            className="bg-blue-500 px-3 py-1 rounded hover:bg-blue-700"
          >
            Bid {amt}
          </button>
        ))}
      </div>

      <div>
        <h3 className="text-lg font-semibold">Current Bids:</h3>
        {Object.entries(bids).map(([user, amount]) => (
          <p key={user}>
            {user}: {amount}
          </p>
        ))}
      </div>
    </div>
  );
}