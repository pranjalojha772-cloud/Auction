import React, { useEffect, useState } from "react";
import { io } from "socket.io-client";
import PlayerCard from "./components/PlayerCard.jsx";
import playersData from "./data/players.json";

const socket = io("http://localhost:5000"); // replace with backend URL

export default function App() {
  const [roomId, setRoomId] = useState("room1");
  const [username, setUsername] = useState("Player1");
  const [auctionPlayers, setAuctionPlayers] = useState(playersData);
  const [squads, setSquads] = useState({});

  useEffect(() => {
    socket.emit("joinRoom", { roomId, username });

    socket.on("updateSquad", (data) => {
      setSquads(data);
    });

    socket.on("matchResult", (data) => {
      alert(`Match ended! Score: ${data.score} Winner: ${data.winner}`);
    });
  }, []);

  const buyPlayer = (player) => {
    socket.emit("buyPlayer", { roomId, player, buyer: username });
  };

  const startMatch = () => {
    socket.emit("startMatch", { roomId });
  };

  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold mb-4">Football Auction Game</h1>

      <h2 className="text-xl mb-2">Auction Players:</h2>
      <div className="grid grid-cols-2 gap-2 mb-4">
        {auctionPlayers.map((p, i) => (
          <div key={i} onClick={() => buyPlayer(p)}>
            <PlayerCard player={p} />
          </div>
        ))}
      </div>

      <button onClick={startMatch} className="bg-green-500 text-white px-4 py-2 rounded">
        Start Match
      </button>

      <h2 className="text-xl mt-6">Your Squad:</h2>
      <div className="grid grid-cols-2 gap-2">
        {(squads[username] || []).map((p, i) => (
          <PlayerCard key={i} player={p} />
        ))}
      </div>
    </div>
  );
}